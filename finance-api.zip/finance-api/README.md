# 💰 Finance API

API REST para **gestão financeira pessoal** construída com Python e Flask.  
Permite registrar receitas e despesas, organizar por categorias e visualizar resumos financeiros.

---

## 🚀 Funcionalidades

- ✅ CRUD completo de transações (receitas e despesas)
- ✅ Gestão de categorias personalizadas
- ✅ Resumo financeiro geral ou por mês
- ✅ Histórico mensal com saldo
- ✅ Filtros por tipo, mês e categoria
- ✅ Banco de dados SQLite (sem configuração extra)
- ✅ Testes automatizados com pytest

---

## 🛠️ Tecnologias

| Tecnologia | Uso |
|---|---|
| Python 3.11+ | Linguagem principal |
| Flask 3.x | Framework web |
| SQLite | Banco de dados |
| pytest | Testes automatizados |

---

## 📁 Estrutura do projeto

```
finance-api/
├── app/
│   ├── __init__.py      # Factory da aplicação
│   ├── database.py      # Conexão e inicialização do banco
│   ├── routes.py        # Todas as rotas (transactions, categories, summary)
│   └── helpers.py       # Funções auxiliares de resposta
├── tests/
│   └── test_api.py      # Testes automatizados
├── run.py               # Ponto de entrada
├── requirements.txt
└── .gitignore
```

---

## ⚙️ Como rodar localmente

**1. Clone o repositório**
```bash
git clone https://github.com/seu-usuario/finance-api.git
cd finance-api
```

**2. Crie um ambiente virtual e instale as dependências**
```bash
python -m venv venv
source venv/bin/activate      # Linux/Mac
venv\Scripts\activate         # Windows

pip install -r requirements.txt
```

**3. Inicie o servidor**
```bash
python run.py
```

A API estará disponível em `http://localhost:5000`.

---

## 📖 Endpoints

### Transações

| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/transactions/` | Lista todas as transações |
| POST | `/transactions/` | Cria uma transação |
| GET | `/transactions/<id>` | Retorna uma transação |
| PUT | `/transactions/<id>` | Atualiza uma transação |
| DELETE | `/transactions/<id>` | Remove uma transação |

**Filtros disponíveis em `GET /transactions/`:**
- `?type=receita` ou `?type=despesa`
- `?month=2024-06`
- `?category_id=1`

**Exemplo de corpo para criar uma transação:**
```json
{
  "description": "Salário junho",
  "amount": 3500.00,
  "type": "receita",
  "date": "2024-06-05",
  "category_id": 1
}
```

---

### Categorias

| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/categories/` | Lista todas as categorias |
| POST | `/categories/` | Cria uma categoria |
| DELETE | `/categories/<id>` | Remove uma categoria |

**Exemplo:**
```json
{
  "name": "Investimentos",
  "type": "receita"
}
```

---

### Resumo financeiro

| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/summary/` | Resumo geral ou por mês (`?month=2024-06`) |
| GET | `/summary/monthly` | Histórico mês a mês |

**Exemplo de resposta de `/summary/?month=2024-06`:**
```json
{
  "status": "success",
  "data": {
    "period": "2024-06",
    "receitas": 3500.00,
    "despesas": 1200.00,
    "saldo": 2300.00,
    "despesas_por_categoria": [
      { "category": "Moradia", "total": 1200.00 }
    ]
  }
}
```

---

## 🧪 Testes

```bash
pytest tests/ -v
```

---

## 📌 Próximos passos

- [ ] Autenticação com JWT
- [ ] Deploy no Railway ou Render
- [ ] Documentação com Swagger (flask-smorest)
- [ ] Suporte a metas de economia

---

## 👤 Autor

Feito por **[Seu Nome]** — [LinkedIn](https://linkedin.com/in/seuperfil) · [GitHub](https://github.com/seuperfil)
