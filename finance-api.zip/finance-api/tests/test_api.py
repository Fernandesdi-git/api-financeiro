import pytest
from app import create_app


@pytest.fixture
def client(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    with app.test_client() as client:
        yield client


# ── Categories ──────────────────────────────────────────────────────────────

def test_list_categories(client):
    res = client.get("/categories/")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "success"
    assert len(data["data"]) > 0  # seed categories exist


def test_create_and_delete_category(client):
    # create
    res = client.post("/categories/", json={"name": "Investimentos", "type": "receita"})
    assert res.status_code == 201
    cat_id = res.get_json()["data"]["id"]

    # duplicate
    res2 = client.post("/categories/", json={"name": "Investimentos", "type": "receita"})
    assert res2.status_code == 409

    # delete
    res3 = client.delete(f"/categories/{cat_id}")
    assert res3.status_code == 200


# ── Transactions ─────────────────────────────────────────────────────────────

def test_create_transaction(client):
    res = client.post("/transactions/", json={
        "description": "Salário junho",
        "amount": 3500.00,
        "type": "receita",
        "date": "2024-06-05",
    })
    assert res.status_code == 201
    assert res.get_json()["data"]["description"] == "Salário junho"


def test_invalid_transaction_missing_fields(client):
    res = client.post("/transactions/", json={"description": "Teste"})
    assert res.status_code == 400


def test_invalid_transaction_negative_amount(client):
    res = client.post("/transactions/", json={
        "description": "Teste",
        "amount": -100,
        "type": "despesa",
        "date": "2024-06-01",
    })
    assert res.status_code == 400


def test_get_update_delete_transaction(client):
    # create
    res = client.post("/transactions/", json={
        "description": "Aluguel",
        "amount": 1200.00,
        "type": "despesa",
        "date": "2024-06-01",
    })
    t_id = res.get_json()["data"]["id"]

    # get
    assert client.get(f"/transactions/{t_id}").status_code == 200

    # update
    res2 = client.put(f"/transactions/{t_id}", json={"amount": 1300.00})
    assert res2.status_code == 200
    assert res2.get_json()["data"]["amount"] == 1300.00

    # delete
    assert client.delete(f"/transactions/{t_id}").status_code == 200

    # not found
    assert client.get(f"/transactions/{t_id}").status_code == 404


# ── Summary ──────────────────────────────────────────────────────────────────

def test_summary(client):
    client.post("/transactions/", json={"description": "Salário", "amount": 5000, "type": "receita", "date": "2024-06-01"})
    client.post("/transactions/", json={"description": "Aluguel", "amount": 1500, "type": "despesa", "date": "2024-06-05"})

    res = client.get("/summary/")
    assert res.status_code == 200
    data = res.get_json()["data"]
    assert data["receitas"] == 5000.0
    assert data["despesas"] == 1500.0
    assert data["saldo"] == 3500.0


def test_monthly_summary(client):
    res = client.get("/summary/monthly")
    assert res.status_code == 200
